import paho.mqtt.publish as publish
import paho.mqtt.subscribe as subscribe
import sys

smc = "Simple MQTT Calculator App\n"

print(smc)

def load(num : int):
    publish.single("dat235/calc/oper/load",num, hostname="localhost")
    msg = subscribe.simple("dat235/calc/eval/#", hostname="localhost")
    print("Accum: %s" % (msg.payload))  

# You write the rest



