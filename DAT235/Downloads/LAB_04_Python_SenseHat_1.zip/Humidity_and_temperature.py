from sense_hat import SenseHat

hat = SenseHat()
humidity = hat.get_humidity()

temp = hat.get_temperature()
print("Luftfuktighet: {:5.2f}".format(humidity))
print("Temperatur på RPI: {:5.2f}".format(temp))

print()

# alternatives
print("Luftfuktighet:",humidity)
print("Temperatur på RPI:",temp)
