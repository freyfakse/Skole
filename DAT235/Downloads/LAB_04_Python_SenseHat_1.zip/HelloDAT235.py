# Hello DAT235 with Tkinter
from tkinter import *

root = Tk()	#	handle for the window
Label(root, text="Hello DAT235").pack()
root.mainloop()
