from sense_hat import SenseHat
from time import sleep
import sys

sense = SenseHat()

x_pos = 0
y_pos = 7

red = (127,0,0)
green = (0,127,0)
blue = (0,0,127)
white = (127,127,127)
yellow = (127,127,0)
black = (0,0,0)

trail = black  # the eater trail
eater = (255,255,0)   # the eater position (bright yellow)

visited = None


def allEaten():
    accum = 0
    for x in range(0,8):
        for y in range(0,8):
            if visited[x][y]: accum += 1
    return (accum==64)


def matrix_init():
    global x_pos, y_pos, visited

    visited = [[False for i in range(0,8)] for j in range(0,8)]
    x_pos = 0
    y_pos = 7   
    sense.clear(white) 
    sense.set_pixel(x_pos,y_pos,eater)
    visited[x_pos][y_pos] = True


def event_loop():
    global x_pos, y_pos
    
    # ***  your code here  ***



if  __name__ == "__main__":
    matrix_init()
    event_loop()
    
    sleep(2)    
    sense.show_message("PixelEater template")
    sleep(1)
    sense.clear()
