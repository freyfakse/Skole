# -*- coding: utf-8 -*-
import socket
from sense_hat import SenseHat
import time

hat = SenseHat()
hat.set_rotation(180)
s = "*** DAT235"
while len(s)>0:
    letter = s[0]
    hat.show_letter(letter, text_colour=[127,127,127])    
    s = s[1:]
    time.sleep(0.3)

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.connect(("8.8.8.8", 80))
ipaddr = s.getsockname()[0]
s.close()
hat.show_message("IP: "+ipaddr, scroll_speed=0.2, text_colour=(127,127,0)) 
hat.clear()
